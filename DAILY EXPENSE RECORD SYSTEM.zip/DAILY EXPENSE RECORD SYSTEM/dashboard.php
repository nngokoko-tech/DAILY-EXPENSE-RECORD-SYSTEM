<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['detsuid']==0)) {
  header('location:logout.php');
} else {
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Daily Expense Tracker - Dashboard</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">

<!-- CUSTOM STYLES -->
<style>
body {
    background-color: #f4f6f9;
}

.panel-expense {
    color: #fff;
    border-radius: 10px;
    box-shadow: 0 6px 15px rgba(0,0,0,0.2);
}

.panel-expense h4 {
    color: #fff;
    font-weight: bold;
}

.bg-today { background: #0d6efd; }
.bg-yesterday { background: #fd7e14; }
.bg-week { background: #20c997; }
.bg-month { background: #dc3545; }
.bg-year { background: #6f42c1; }
.bg-total { background: #198754; }

.easypiechart .percent {
    font-size: 22px;
    font-weight: bold;
}
</style>
</head>

<body>

<?php include_once('includes/header.php');?>
<?php include_once('includes/sidebar.php');?>

<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">

<h1 class="page-header">Dashboard</h1>

<div class="row">

<?php
$userid=$_SESSION['detsuid'];
$tdate=date('Y-m-d');
$ydate=date('Y-m-d',strtotime("-1 days"));
$pastdate=date("Y-m-d", strtotime("-1 week"));
$monthdate=date("Y-m-d", strtotime("-1 month"));
$crrntdte=date("Y-m-d");
$cyear=date("Y");
?>

<!-- TODAY -->
<div class="col-xs-6 col-md-3">
<div class="panel panel-expense bg-today">
<div class="panel-body text-center">
<?php
$q=mysqli_query($con,"select sum(ExpenseCost) as t from tblexpense where ExpenseDate='$tdate' && UserId='$userid'");
$r=mysqli_fetch_array($q);
?>
<h4>Today's Expense</h4>
<h2><?php echo $r['t'] ?: 0; ?></h2>
</div>
</div>
</div>

<!-- YESTERDAY -->
<div class="col-xs-6 col-md-3">
<div class="panel panel-expense bg-yesterday">
<div class="panel-body text-center">
<?php
$q=mysqli_query($con,"select sum(ExpenseCost) as t from tblexpense where ExpenseDate='$ydate' && UserId='$userid'");
$r=mysqli_fetch_array($q);
?>
<h4>Yesterday</h4>
<h2><?php echo $r['t'] ?: 0; ?></h2>
</div>
</div>
</div>

<!-- WEEK -->
<div class="col-xs-6 col-md-3">
<div class="panel panel-expense bg-week">
<div class="panel-body text-center">
<?php
$q=mysqli_query($con,"select sum(ExpenseCost) as t from tblexpense where ExpenseDate between '$pastdate' and '$crrntdte' && UserId='$userid'");
$r=mysqli_fetch_array($q);
?>
<h4>Last 7 Days</h4>
<h2><?php echo $r['t'] ?: 0; ?></h2>
</div>
</div>
</div>

<!-- MONTH -->
<div class="col-xs-6 col-md-3">
<div class="panel panel-expense bg-month">
<div class="panel-body text-center">
<?php
$q=mysqli_query($con,"select sum(ExpenseCost) as t from tblexpense where ExpenseDate between '$monthdate' and '$crrntdte' && UserId='$userid'");
$r=mysqli_fetch_array($q);
?>
<h4>Last 30 Days</h4>
<h2><?php echo $r['t'] ?: 0; ?></h2>
</div>
</div>
</div>

<!-- YEAR -->
<div class="col-xs-6 col-md-3">
<div class="panel panel-expense bg-year">
<div class="panel-body text-center">
<?php
$q=mysqli_query($con,"select sum(ExpenseCost) as t from tblexpense where year(ExpenseDate)='$cyear' && UserId='$userid'");
$r=mysqli_fetch_array($q);
?>
<h4>This Year</h4>
<h2><?php echo $r['t'] ?: 0; ?></h2>
</div>
</div>
</div>

<!-- TOTAL -->
<div class="col-xs-6 col-md-3">
<div class="panel panel-expense bg-total">
<div class="panel-body text-center">
<?php
$q=mysqli_query($con,"select sum(ExpenseCost) as t from tblexpense where UserId='$userid'");
$r=mysqli_fetch_array($q);
?>
<h4>Total Expense</h4>
<h2><?php echo $r['t'] ?: 0; ?></h2>
</div>
</div>
</div>

</div>
</div>

<?php include_once('includes/footer.php');?>

<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>
<?php } ?>